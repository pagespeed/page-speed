/*
 * pngxwrite.c - libpng external I/O: write utility functions.
 * Copyright (C) 2001-2005 Cosmin Truta.
 */

#if 0
#error No external writing is implemented yet.
#endif
